Dim's enviromental and architectural textures (26 textures).

They're all fairly high quality (most are 1024x1024);
Normal Maps are included.

Original source:
http://blenderartists.org/forum/showthread.php?t=131009

Personal communication with author:

"All of those textures are original work, and I am releasing them with the CC Attribution 3.0 license"

http://creativecommons.org/licenses/by/3.0/




